# Portfolio Website Template 2

this is a preview of how the index file hero section looks like.

![porfolio template 2](../Previews/Portfolio-Website-Template-2.png)

## Directory downoald steps

To downolad this directory follow these steps:

1. Copy the directory's URL
2.  navigate to https://download-directory.github.io/
3. paste the URL into the text box, and hit enter

## Features

- Responsive design
- Accessible for all users
- Easy to customize
- Minimalist design for showcasing your portfolio